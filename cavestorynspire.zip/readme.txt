Cave story (NXEngine)
Ported to TI Nspire by gameblabla
TI Nspire version, Build January 18th 2017
Game now run fullspeed ! Enjoy


==========
Installation 
==========

Put all the files anywhere in your calc but the folder data must be right next to cave.tns, stage.dat.tns, sprites.sif.tns and tilekey.dat.tns.
